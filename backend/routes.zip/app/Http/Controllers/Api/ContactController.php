<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContactSubmission;
use App\Models\SiteContent;
use App\Support\SiteContentDefaults;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function info(): JsonResponse
    {
        return response()->json([
            'contact' => $this->value('contact_info', SiteContentDefaults::contactInfo()),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255'],
            'sub' => ['required', 'string', 'max:255'],
            'sms' => ['required', 'string', 'max:5000'],
        ]);

        $contact = ContactSubmission::query()->create([
            'name' => $data['name'],
            'email' => $data['email'],
            'subject' => $data['sub'],
            'message' => $data['sms'],
            'status' => 'New',
        ]);

        $this->sendWelcomeMail($contact);

        return response()->json([
            'message' => 'Contact request submitted successfully.',
        ]);
    }

    private function sendWelcomeMail(ContactSubmission $contact): void
    {
        $smtp = $this->value('smtp_settings', SiteContentDefaults::smtpSettings());
        $contactInfo = $this->value('contact_info', SiteContentDefaults::contactInfo());

        if (empty($smtp['host']) || empty($smtp['port']) || empty($smtp['from_email'])) {
            return;
        }

        config([
            'mail.default' => 'smtp',
            'mail.mailers.smtp.transport' => 'smtp',
            'mail.mailers.smtp.host' => $smtp['host'],
            'mail.mailers.smtp.port' => (int) $smtp['port'],
            'mail.mailers.smtp.username' => $smtp['username'] ?? '',
            'mail.mailers.smtp.password' => $smtp['password'] ?? '',
            'mail.mailers.smtp.encryption' => ($smtp['encryption'] ?? 'tls') === 'none' ? null : ($smtp['encryption'] ?? 'tls'),
            'mail.from.address' => $smtp['from_email'],
            'mail.from.name' => $smtp['from_name'] ?: 'PEACEMAIN',
        ]);

        $subject = $contactInfo['welcome_subject'] ?? 'Welcome to PEACEMAIN';
        $template = $smtp['mail_template_html'] ?? '';
        $welcomeMessage = $contactInfo['welcome_message'] ?? 'Thanks for contacting us. Our team will get back to you shortly.';

        if (! $template) {
            $template = '<div style="font-family:Arial,sans-serif;padding:24px"><h2>Welcome [[name]]</h2><p>[[welcome_message]]</p><p>Regards,<br>[[from_name]]</p></div>';
        }

        $values = [
            $contact->name,
            $contact->email,
            $contact->subject,
            e($contact->message),
            nl2br(e($welcomeMessage)),
            $smtp['from_name'] ?: 'PEACEMAIN',
        ];
        $html = str_replace(
            ['[[name]]', '[[email]]', '[[subject]]', '[[message]]', '[[welcome_message]]', '[[from_name]]'],
            $values,
            $template
        );
        $html = str_replace(
            ['{{name}}', '{{email}}', '{{subject}}', '{{message}}', '{{welcome_message}}', '{{from_name}}'],
            $values,
            $html
        );

        try {
            Mail::html($html, function ($message) use ($contact, $subject): void {
                $message->to($contact->email)->subject($subject);
            });
        } catch (\Throwable $exception) {
            Log::error('Welcome mail send failed', [
                'contact_submission_id' => $contact->id,
                'error' => $exception->getMessage(),
            ]);
        }
    }

    private function value(string $key, mixed $default): mixed
    {
        $record = SiteContent::query()->where('key', $key)->first();

        return $record?->value ?? $default;
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SiteContent;
use App\Support\SiteContentDefaults;
use Illuminate\Http\JsonResponse;

class SiteContentController extends Controller
{
    public function banner(): JsonResponse
    {
        return response()->json([
            'data' => $this->value('banner', SiteContentDefaults::banners()),
        ]);
    }

    public function sidebar(): JsonResponse
    {
        return response()->json([
            'data' => $this->value('sidebar', SiteContentDefaults::sidebarLinks()),
        ]);
    }

    public function faq(): JsonResponse
    {
        return response()->json([
            'data' => $this->value('faq', SiteContentDefaults::faqs()),
        ]);
    }

    public function contactInfo(): JsonResponse
    {
        return response()->json([
            'data' => $this->value('contact_info', SiteContentDefaults::contactInfo()),
        ]);
    }

    public function generalSettings(): JsonResponse
    {
        return response()->json([
            'data' => $this->value('general_settings', SiteContentDefaults::generalSettings()),
        ]);
    }

    private function value(string $key, mixed $default): mixed
    {
        $record = SiteContent::query()->where('key', $key)->first();

        return $record?->value ?? $default;
    }
}
